# Group B
## Admin User Interface
## Course Coordinator User Interface
### e19-CO225-Student-Result-Management-System
Student Results Management System Mobile Application - CO225
